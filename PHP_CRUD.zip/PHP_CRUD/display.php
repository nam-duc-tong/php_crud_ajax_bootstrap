<?php include 'connect.php';?>
    <table class="table my-4">
            <thead class="table-dark">
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Place</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <?php
                    if(isset($_POST['displaySend']))
                    {
                        $i=0;
                        $sql = "Select * from `crud`";
                        $result = mysqli_query($con,$sql);
                        while($row=mysqli_fetch_assoc($result))
                        { 
                            $i++;
                            $id = $row['id'];
                            $name = $row['name'];
                            $email = $row['email'];
                            $mobile = $row['mobile'];
                            $place = $row['place'];
                ?>
                   <tr>
                        <td scope="row"><?php echo $i;?></td>
                        <td scope="row"><?php echo $name;?></td>
                        <td scope="row"><?php echo $email;?></td>
                        <td scope="row"><?php echo $mobile;?></td>
                        <td scope="row"><?php echo $place;?></td>
                        <td>
                            <button class="btn btn-dark" onclick="GetDetails(<?php echo $id;?>)">Update</button>
                            <button class="btn btn-danger" onclick="DeleteUser(<?php echo $id;?>)">Delete</button>
                        </td>
                   </tr>
                <?php
                        }
                    }
                ?>
            </tbody>
        </table>